#include "matrix.h"
#include <vector>
#include<algorithm> 
#include <string>
#include <iostream>
//includes for program

using namespace std;
//namespace

/**
* Name: Humna Sultan
* Program Name: Create a Matrix Class
* Date: 5 March 2020
* Extra Thing: Asks user for row and column values (other file)
*/

matrix::matrix(int r, int c) {
	//constructor
	
	rows = r;
	col = c;
	//makes global private variables equal to parameters

	mat.resize(r, vector<int>(c, 0));
	//resizes array to fill requirements
}

void matrix::fill(int v, int r, int c)
{
	mat[r][c] = v;
	//fills value in element
}
//method for printing

ostream& operator<<(ostream& output, const matrix& Matty) 
//ostream operator allows for printing
{
	for (int k = 0; k < Matty.rows; k++)
	{
		for (int p = 0; p < Matty.col; p++)
		{
			cout << Matty.mat[k][p] << " ";
			//prints element
		}
		cout << endl;
		//goes to a new line for next row
	}
	//for loops for printing
	return output;
}