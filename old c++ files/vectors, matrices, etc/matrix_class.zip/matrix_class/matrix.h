#pragma once
#include <vector>
#include <iostream>
//includes

using namespace std;
//namespace

/**
* Name: Humna Sultan
* Program Name: Create a Matrix Class
* Date: 5 March 2020
* Extra Thing: Asks user for row and column values (other file)
*/

class matrix {

private:
	vector <vector<int>> mat;
	//global array for use
	int rows;
	int col;
	//global variables for getting rows and cols
public:
	matrix(int, int);
	void fill(int, int, int);
	//methods in matrix.cpp
	friend ostream& operator<<(ostream&, const matrix&);
	//ostream method declaration in header
};

