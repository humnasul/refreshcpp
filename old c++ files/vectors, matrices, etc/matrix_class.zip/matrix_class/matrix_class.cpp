#include "matrix.h"
#include <vector>
#include <iostream>
//includes

using namespace std;
//namesapace

/**
* Name: Humna Sultan
* Program Name: Create a Matrix Class
* Date: 5 March 2020
* Extra Thing: Asks user for row and column values
*/

int main()
{
	int rows;
	int col;

	cout << "Enter number for rows :: ";
	cin >> rows;
	cout << "Enter number for columns :: ";
	cin >> col;
	//declares rows and columns. Asks user for values
	//extra

	matrix m = matrix(rows, col);
	//creates object

	int n = 1;
	//n is used for filling elements in vector

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < col; j++)
			{
				n = n * 2;
				//multiples value for each column
				m.fill(n, i, j);
				//calls function to fill corresponding element
			}
		n = 1;
		//resets variable for new row
	}
	//for loops for filling elements

	cout << m;
	//required for printing vector
}

